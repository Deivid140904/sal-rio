package com.example.salrio;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edtSalario;
    RadioGroup rgPercentual;
    RadioButton rb40, rb45, rb50;
    Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSalario = findViewById(R.id.edtSalario);
        rgPercentual = findViewById(R.id.rgPercentual);
        rb40 = findViewById(R.id.rb40);
        rb45 = findViewById(R.id.rb45);
        rb50 = findViewById(R.id.rb50);
        btnCalcular = findViewById(R.id.btnCalcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String salarioStr = edtSalario.getText().toString();

                if (salarioStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite o salário!", Toast.LENGTH_SHORT).show();
                    return;
                }

                double salario = Double.parseDouble(salarioStr);
                double novoSalario = 0;

                if (rb40.isChecked()) {
                    novoSalario = salario + (salario * 0.40);
                } else if (rb45.isChecked()) {
                    novoSalario = salario + (salario * 0.45);
                } else if (rb50.isChecked()) {
                    novoSalario = salario + (salario * 0.50);
                } else {
                    Toast.makeText(MainActivity.this, "Selecione um percentual!", Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(MainActivity.this,
                        "Novo salário: R$ " + String.format("%.2f", novoSalario),
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
